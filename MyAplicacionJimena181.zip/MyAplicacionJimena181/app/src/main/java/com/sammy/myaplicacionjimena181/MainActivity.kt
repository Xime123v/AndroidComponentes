package com.sammy.myaplicacionjimena181

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageButton
import android.widget.RadioButton
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import android.widget.ToggleButton

class MainActivity : AppCompatActivity() {

    var radio1: RadioButton? = null
    var radio2: RadioButton? = null
    var check1: CheckBox? = null
    var check2: CheckBox? = null
    var ToogleButon: ToggleButton? = null
    var text7: TextView? = null
    var swiitch: Switch? = null
    var textSwitch: TextView? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val boton1: Button = findViewById(R.id.button)
        boton1.setOnClickListener { validar() }

        val boton2: ToggleButton = findViewById(R.id.toggleButton)
        boton2.setOnClickListener { onclick4() }

        val boton3: Switch = findViewById(R.id.switch2)
        boton3.setOnClickListener { OnclickListener3() }





        radio1 = findViewById(R.id.radioButton2)
        radio2 = findViewById(R.id.radioButton5)
        check1 = findViewById(R.id.checkBox)
        check2 = findViewById(R.id.checkBox2)
        ToogleButon = findViewById(R.id.toggleButton)
        text7 = findViewById(R.id.textView7)
        swiitch = findViewById(R.id.switch2)
        textSwitch = findViewById(R.id.textSwi)



    }

    fun saludo(view: View){
        var texto=view.contentDescription.toString()
        if(texto=="Hola"){
            Toast.makeText(this,"Jimena",Toast.LENGTH_LONG).show()
        }
    }

    private fun validar() {

        val campoNumero: EditText = findViewById(R.id.editTextTextPersonName)
        var nombre = campoNumero.text


        var cad: String = ""

        if (radio1?.isChecked == true) {
            cad += "Radio1 Seleccionado\n"
        }
        if (radio2?.isChecked == true) {
            cad += "Radio2 Seleccionado\n"
        }


        var opc: String = ""
        if (check1?.isChecked == true) {
            opc += "Check1 Seleccionado \n"
        }
        if (check2?.isChecked == true) {
            opc += "Check2 Seleccionado \n"
        }


        var ops: String = ""
        if (ToogleButon?.isChecked == true) {
            text7?.setText("Boton on")
            ops += "ToogleButton seleccionado \n"
        } else {
            text7?.setText("Boton off")
            ops += "ToogleButton seleccionado \n"
        }


        var opcio: String = ""
        if (swiitch?.isChecked == true) {
            textSwitch?.setText("Prendido")
            opcio += "switch seleccionado \n"
        } else {
            textSwitch?.setText("Apagado")
            opcio += "switch seleccionado \n"
        }






        Toast.makeText(this, "  $cad $opc $ops $opcio $nombre", Toast.LENGTH_LONG).show()

    }

    fun onclick4() {

        if (ToogleButon?.isChecked == true) {
            text7?.setText("Boton on")
        } else {
            text7?.setText("Boton off")
        }

    }

    fun OnclickListener3() {
        if (swiitch?.isChecked == true) {
            textSwitch?.setText("Prendidio")
        } else {
            textSwitch?.setText("Apagado")
        }
    }



}







